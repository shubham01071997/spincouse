package com.SprinCourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprinCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
