package com.SprinCourse.Services;

import java.util.List;

import com.SprinCourse.Entity.Course;

public interface CourseServices {
	public Course save(Course course);
	public Course update(Course course,Long id);
	public List<Course> findAllCourse();
	public void deleteById(Long id);
	public Course FindById(long id);
	

}
