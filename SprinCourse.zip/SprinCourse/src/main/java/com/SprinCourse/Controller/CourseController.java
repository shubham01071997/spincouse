package com.SprinCourse.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.SprinCourse.Entity.Course;
import com.SprinCourse.Services.CourseServices;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/course")
public class CourseController {
	
	@Autowired
	private CourseServices courseservice;
	
	@PostMapping("/add")
	public String save(@RequestBody Course course){
		Course save = courseservice.save(course);
		if(save!=null) {
			return "success";
		}else {
			return "fail";
		}
	}
	
	@PutMapping("/update/{id}")
	public String save(@RequestBody Course course,@PathVariable("id") long id){
		Course update = courseservice.update(course,id);
		if(update!=null) {
			return "update";
		}else {
			return "fail";
		}
	}
	
	@GetMapping
	public List<Course> findAllCourse(){
		return courseservice.findAllCourse();	
	}
	
	@DeleteMapping("{id}")
	public  ResponseEntity<HttpStatus> delete(@PathVariable("id")long id) {
		try {
			courseservice.deleteById(id);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("{id}")
	public Course findById(@PathVariable("id")long id){
		Course findById = courseservice.FindById(id);
		return findById;
	}
}
