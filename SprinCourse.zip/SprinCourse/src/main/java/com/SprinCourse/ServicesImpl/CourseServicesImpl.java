package com.SprinCourse.ServicesImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SprinCourse.Entity.Course;
import com.SprinCourse.Repository.CourseRepository;
import com.SprinCourse.Services.CourseServices;
@Service
public class CourseServicesImpl implements CourseServices {
	
	@Autowired
	private CourseRepository courseRepo;
   	

	@Override
	public Course save(Course course) {
		Course save = courseRepo.save(course);
		return save;
	}

	@Override
	public Course update(Course course, Long id) {
		Optional<Course> findById = courseRepo.findById(id);
		Course data = findById.get();
		data.setDescription(course.getDescription());
		data.setCourse(course.getCourse());
		Course update = courseRepo.save(data);
		return update;
	}

	@Override
	public List<Course> findAllCourse() {
		List<Course> findAll = courseRepo.findAll();
		return findAll;
	}

	@Override
	public void deleteById(Long id) {
		courseRepo.deleteById(id);
	}

	@Override
	public Course FindById(long id) {
		Optional<Course> findById = courseRepo.findById(id);
		Course data = findById.get();
		return data;
	}
}
