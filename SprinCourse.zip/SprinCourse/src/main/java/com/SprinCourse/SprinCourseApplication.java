package com.SprinCourse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinCourseApplication.class, args);
	}

}
